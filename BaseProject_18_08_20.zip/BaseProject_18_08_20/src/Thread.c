
#include "cmsis_os.h"  // CMSIS RTOS header file
#include "Board_LED.h"
#include "UART_driver.h"
#include "stdint.h"                     // data type definitions
#include "stdio.h"                      // file I/O functions
#include "rl_usb.h"                     // Keil.MDK-Pro::USB:CORE
#include "rl_fs.h"                      // Keil.MDK-Pro::File System:CORE
#include "stm32f4xx_hal.h"
#include "stm32f4_discovery.h"
#include "stm32f4_discovery_audio.h"
#include "math.h"
#include "arm_math.h" // header for DSP library
#include <stdio.h>

// LED constants
#define LED_Green   0
#define LED_Orange  1
#define LED_Red     2
#define LED_Blue    3

//Receive Thread
#define Show_Files_char "1"
#define search_char "4"
enum commands{
  getFiles,
  fileClicked,
  playPressed,
	pausePressed,
	newFile,
	finishedSong
};
// State Machine definitions
enum state{
  idle,
  fileDisplay,
  fileSelected,
	play,
	pause
};

// Control Thread
void Control (void const *argument); // thread function
osThreadId tid_Control; // thread id
osThreadDef (Control, osPriorityNormal, 1, 0); // thread object

// Command queue from Rx_Command to Controller
osMessageQId mid_CMDQueue; // message queue for commands to Thread
osMessageQDef (CMDQueue, 1, uint32_t); // message queue object

// Command queue from Rx_Command to Controller
osMessageQId Command_FSQueue; // message queue for commands to Thread
osMessageQDef (FSQueue, 1, uint32_t); // message queue object

// UART receive thread
void Rx_Command (void const *argument);  // thread function
osThreadId tid_RX_Command;  // thread id
osThreadDef (Rx_Command, osPriorityNormal, 1, 0); // thread object

// UART receive thread
void FS (void const *argument);  // thread function
osThreadId tid_FS;  // thread id
osThreadDef (FS, osPriorityNormal, 1, 0); // thread object

void Process_Event(uint16_t event){
  static uint16_t   Current_State = idle; // Current state of the SM
  switch(Current_State){
    case idle:
			if(event == getFiles){
        Current_State = fileDisplay;
        // Exit actions
        LED_Off(LED_Red);
        // Transition actions
        // List entry actions
        LED_On(LED_Blue);
				//osMessagePut (Command_FSQueue, SendFiles, osWaitForever);
      }
      break;
    case fileDisplay:
      if(event == fileClicked){
        Current_State = fileSelected;
        // Exit actions
        LED_Off(LED_Blue);
        // Transition actions
        // List entry actions
        LED_On(LED_Green);
				//osMessagePut (Command_FSQueue, SendFiles, osWaitForever);
      }
      break;
    case fileSelected:
      if(event == playPressed){
        Current_State = play;
        // Exit actions
        LED_Off(LED_Blue);
        // Transition actions
        // Idle entry actions
        LED_On(LED_Red);     
      } 
      break;
		case play:
      if(event == pausePressed){
        Current_State = pause;
        // Exit actions
        LED_Off(LED_Blue);
        // Transition actions
        // Idle entry actions
        LED_On(LED_Red);     
      } 
      break;
		case pause:
      if(event == newFile){
        Current_State = fileSelected;
        // Exit actions
        LED_Off(LED_Blue);
        // Transition actions
        // Idle entry actions
        LED_On(LED_Red);     
      } 
      break;
    default:
      break;
  } // end case(Current_State)
} // Process_Event




void Init_Thread (void) {

	osThreadId id; // holds the returned thread create ID
	
	LED_Initialize(); // Initialize the LEDs
	UART_Init(); // Initialize the UART
	// Create queues
   mid_CMDQueue = osMessageCreate (osMessageQ(CMDQueue), NULL);  // create msg queue
  if (!mid_CMDQueue)return; // Message Queue object not created, handle failure
	
	 Command_FSQueue = osMessageCreate (osMessageQ(FSQueue), NULL);  // create msg queue
  if (!Command_FSQueue)return; // Message Queue object not created, handle failure
	
  // Create threads
   tid_RX_Command = osThreadCreate (osThread(Rx_Command), NULL);
  if (!tid_RX_Command) return;
   tid_Control = osThreadCreate (osThread(Control), NULL);
  if (!tid_Control) return;
	   tid_FS = osThreadCreate (osThread(FS), NULL);
  if (!tid_FS) return;
	
}

// Thread function
void Control(void const *arg){
  osEvent evt; // Receive message object
  Process_Event(0); // Initialize the State Machine
	
   while(1){
    evt = osMessageGet (mid_CMDQueue, osWaitForever); // receive command
      if (evt.status == osEventMessage) { // check for valid message
      Process_Event(evt.value.v); // Process event
    }
   }
}

void Rx_Command (void const *argument){
   char rx_char[2]={0,0};
	 char rx_store[20]={0};
   while(1){
			UART_receive(rx_char, 1); // Wait for command from PC GUI
    // Check for the type of character received
      if(!strcmp(rx_char,Show_Files_char)){
         // Trigger1 received
         osMessagePut (mid_CMDQueue, getFiles, osWaitForever);
      }else if (!strcmp(rx_char,search_char)){
				// 4 received
				UART_receivestring(rx_store,20);
				
//        // Trigger2 received
//         osMessagePut (mid_CMDQueue, SendComplete, osWaitForever);
//			} else if (!strcmp(rx_char,End_File_List_char)){
//        // Trigger3 received
//         osMessagePut (mid_CMDQueue, SendFiles, osWaitForever);
     } // end if
   }
} // end Rx_Command

void FS (void const *argument){	
	usbStatus ustatus; // USB driver status variable
	uint8_t drivenum = 0; // Using U0: drive number
	char *drive_name = "U0:"; // USB drive name
	fsStatus fstatus; // file system status variable
	static FILE *f;
	osEvent evt; // Receive message object
	char *StartFileList_msg = "2\n";
	char *EndFileList_msg = "3\n";
	char *SelectedItem_msg = "4\n";
	char *file_name = "TestFileName.txt";
	int len;
	fsFileInfo info;
	
	LED_On(LED_Green);
	ustatus = USBH_Initialize (drivenum); // initialize the USB Host
	if (ustatus == usbOK){
		// loop until the device is OK, may be delay from Initialize
		ustatus = USBH_Device_GetStatus (drivenum); // get the status of the USB device
		while(ustatus != usbOK){
			ustatus = USBH_Device_GetStatus (drivenum); // get the status of the USB device
		}
		// initialize the drive
		fstatus = finit (drive_name);
		if (fstatus != fsOK){
			// handle the error, finit didn't work
		} // end if
		// Mount the drive
		fstatus = fmount (drive_name);
		if (fstatus != fsOK){
			// handle the error, fmount didn't work
		} // end if 
		while(1){
			evt = osMessageGet (Command_FSQueue, osWaitForever); // receive command
			if (evt.status == osEventMessage) { // check for valid message
				 UART_send(StartFileList_msg,2); // Send start string
				info.fileID = 0;
				while (ffind ("*.txt", &info) == fsOK){
				UART_send((char*)info.name,strlen(info.name));
				UART_send("\r\n",2);
			}
				 len = strlen(file_name);
				 UART_send(file_name,len);
				 UART_send("\n",1); // this is the VB string terminator "\n"
				 UART_send(EndFileList_msg,2); // Send ending string
			}
		}	 
			
		// file system and drive are good to go
		f = fopen ("Test.txt","w");// open a file on the USB device for writing
		if (f != NULL) {
			fputs("Testing an OTG USB device.\n", f); // write a string to the file
			fclose (f); // close the file
		}
		 }// end if USBH_Initialize
	LED_Off(LED_Green);

}
